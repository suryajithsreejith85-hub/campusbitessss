
import React, { useState } from 'react';
import { geminiService } from '../services/geminiService';
import { MENU_ITEMS } from '../data';

const AIAssistant: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [response, setResponse] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;

    setIsLoading(true);
    const result = await geminiService.getFoodRecommendation(query, MENU_ITEMS);
    setResponse(result);
    setIsLoading(false);
  };

  return (
    <div className="fixed bottom-6 right-6 z-40">
      {isOpen ? (
        <div className="bg-white rounded-2xl shadow-2xl w-80 mb-4 border border-indigo-100 overflow-hidden flex flex-col animate-slide-up">
          <div className="bg-indigo-600 p-4 text-white flex justify-between items-center">
            <div className="flex items-center gap-2">
              <div className="bg-white p-1 rounded-full">
                <svg className="w-5 h-5 text-indigo-600" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM7 9a1 1 0 100-2 1 1 0 000 2zm7-1a1 1 0 11-2 0 1 1 0 012 0zm-7.535 4.01a1 1 0 011.415 0 2.999 2.999 0 004.24 0 1 1 0 111.414 1.414 4.999 4.999 0 01-7.07 0 1 1 0 010-1.414z" clipRule="evenodd" />
                </svg>
              </div>
              <span className="font-bold">Canteen AI Bot</span>
            </div>
            <button onClick={() => setIsOpen(false)} className="hover:bg-indigo-500 rounded p-1">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>

          <div className="p-4 h-64 overflow-y-auto bg-indigo-50">
            {response ? (
              <div className="bg-white p-3 rounded-lg shadow-sm border border-indigo-100 text-sm text-gray-700 animate-fade-in">
                {response}
                <button 
                  onClick={() => setResponse(null)} 
                  className="block mt-2 text-indigo-600 font-semibold"
                >
                  Ask again
                </button>
              </div>
            ) : (
              <p className="text-gray-500 text-sm text-center italic mt-12">
                "What should I eat for under ₹100?"<br/>
                "Recommend a healthy breakfast"
              </p>
            )}
            {isLoading && (
              <div className="flex justify-center mt-4">
                <div className="w-6 h-6 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin"></div>
              </div>
            )}
          </div>

          <form onSubmit={handleSubmit} className="p-3 border-t bg-white">
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Type your cravings..."
              className="w-full px-3 py-2 border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </form>
        </div>
      ) : (
        <button 
          onClick={() => setIsOpen(true)}
          className="bg-indigo-600 text-white p-4 rounded-full shadow-lg hover:bg-indigo-700 transform hover:scale-110 transition-all flex items-center justify-center"
        >
          <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M18 10c0 3.866-3.582 7-8 7a8.841 8.841 0 01-4.083-.98L2 17l1.338-3.123C2.493 12.767 2 11.434 2 10c0-3.866 3.582-7 8-7s8 3.134 8 7zM7 9H5v2h2V9zm8 0h-2v2h2V9zM9 9h2v2H9V9z" clipRule="evenodd" />
          </svg>
        </button>
      )}
    </div>
  );
};

export default AIAssistant;
