
import { GoogleGenAI, Type } from "@google/genai";
import { FoodItem } from "../types";

export class GeminiService {
  private ai: GoogleGenAI;

  constructor() {
    this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  }

  async getFoodRecommendation(query: string, menu: FoodItem[]): Promise<string> {
    const prompt = `
      You are a friendly college canteen assistant. 
      The student says: "${query}"
      
      Here is our current menu:
      ${JSON.stringify(menu.map(i => ({ name: i.name, price: i.price, category: i.category, rating: i.rating })))}
      
      Recommend 1-2 items from the menu based on their query. Be concise and student-friendly.
      If they ask for something not on the menu, suggest the closest alternative.
    `;

    try {
      const response = await this.ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
      });
      return response.text || "I'm not sure what to recommend, but the Maggi is always a great choice!";
    } catch (error) {
      console.error("Gemini Error:", error);
      return "Oops, I'm having trouble thinking right now. Maybe try the Biryani?";
    }
  }
}

export const geminiService = new GeminiService();
